<?php
// index.php - Landing page
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Farm Digital Marketing System</title>
  <style>
    /* Fade-in animation for page */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      /* Background image with overlay */
      background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)),
                  url('assets/f2.jpg') no-repeat center center/cover;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      color: #fff;
      animation: fadeIn 1s ease forwards;
    }

    h1 {
      margin-bottom: 50px;
      font-size: 3rem;
      text-align: center;
      text-shadow: 2px 2px 6px rgba(0,0,0,0.5);
      animation: fadeIn 1s ease forwards;
    }

    .buttons {
      display: flex;
      gap: 30px;
      flex-wrap: wrap;
      justify-content: center;
      animation: fadeIn 1.5s ease forwards;
    }

    .panel-btn {
      padding: 20px 45px;
      font-size: 1.2rem;
      font-weight: bold;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      transition: transform 0.3s, background 0.3s, box-shadow 0.3s;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      color: #fff;
    }

    .panel-btn:hover {
      transform: translateY(-7px) scale(1.05);
      box-shadow: 0 10px 25px rgba(0,0,0,0.4);
    }

    .admin { background-color: #FF6F61; }
    .employee { background-color: #FFA500; }
    .customer { background-color: #00BFFF; }

    /* Mobile responsiveness */
    @media (max-width: 600px) {
      .buttons {
        flex-direction: column;
        gap: 20px;
      }
      h1 {
        font-size: 2rem;
      }
    }
  </style>
</head>
<body>

  <h1>Farm Digital Marketing System</h1>

  <div class="buttons">
    <form action="admin/login.php" method="get">
      <button type="submit" class="panel-btn admin">Admin Login</button>
    </form>
    
    <form action="employee/login.php" method="get">
      <button type="submit" class="panel-btn employee">Employee Login</button>
    </form>
    
    <form action="customer/login.php" method="get">
      <button type="submit" class="panel-btn customer">Customer Login</button>
    </form>
  </div>

</body>
</html>
