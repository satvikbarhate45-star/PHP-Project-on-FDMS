<?php
session_start();
include('../config.php');

// Fetch all employees
$employees_result = mysqli_query($conn, "SELECT * FROM employees ORDER BY created_at DESC");
$employees = mysqli_fetch_all($employees_result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employees | Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Montserrat', sans-serif;
    margin:0;
    padding:0;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('../assets/farm7.jpg') no-repeat center center/cover;
    color:#fff;
    animation: fadeBody 1s ease forwards;
}
@keyframes fadeBody { from {opacity:0;} to {opacity:1;} }

.header {
    background:#FFD700;
    padding:25px 0;
    text-align:center;
    color:#333;
    font-weight:600;
    text-shadow:1px 1px 3px rgba(0,0,0,0.2);
    border-bottom-left-radius:20px;
    border-bottom-right-radius:20px;
}
.header h1 { margin:0; font-size:2rem; }

.container {
    width:90%;
    max-width:1200px;
    margin:30px auto;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding:25px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.4);
}

h2 {
    text-align:center;
    margin-bottom:25px;
    color:#FFD700;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
}

.table-container {
    overflow-x:auto;
}

table {
    width:100%;
    border-collapse: collapse;
    margin-top:15px;
}

th, td {
    padding:12px;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,0.3);
}

th {
    background: rgba(255,215,0,0.3);
    color:#333;
    font-weight:600;
}

tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition:0.2s;
}

.back-btn {
    display:block;
    width:max-content;
    margin:20px auto 0;
    text-align:center;
    background:#FFD700;
    color:#333;
    padding:12px 25px;
    border-radius:10px;
    font-weight:600;
    text-decoration:none;
    transition:0.3s;
}
.back-btn:hover {
    background:#e6c200;
    transform: translateY(-2px) scale(1.05);
    box-shadow:0 8px 25px rgba(0,0,0,0.3);
}

@media(max-width:768px){
    table, thead, tbody, th, td, tr { display:block; }
    th { position:absolute; top:-9999px; left:-9999px; }
    td { border:none; position:relative; padding-left:50%; margin-bottom:10px; }
    td:before { 
        position:absolute; 
        top:12px; 
        left:12px; 
        width:45%; 
        white-space: nowrap; 
        font-weight:bold; 
        content: attr(data-label);
    }
}
</style>
</head>
<body>

<div class="header">
    <h1>👨‍🌾 Employees List</h1>
</div>

<div class="container">
    <h2>All Employees</h2>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Farm Type</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php if($employees): ?>
                    <?php foreach($employees as $emp): ?>
                        <tr>
                            <td data-label="ID"><?= $emp['employee_id'] ?></td>
                            <td data-label="Full Name"><?= htmlspecialchars($emp['full_name']) ?></td>
                            <td data-label="Username"><?= htmlspecialchars($emp['username']) ?></td>
                            <td data-label="Email"><?= htmlspecialchars($emp['email']) ?></td>
                            <td data-label="Phone"><?= htmlspecialchars($emp['phone']) ?></td>
                            <td data-label="Farm Type"><?= htmlspecialchars($emp['farm_type']) ?></td>
                            <td data-label="Created At"><?= date('d-m-Y H:i', strtotime($emp['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align:center;">No employees found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <a href="dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
</div>

</body>
</html>
