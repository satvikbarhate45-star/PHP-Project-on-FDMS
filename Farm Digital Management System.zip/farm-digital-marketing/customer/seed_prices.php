<?php
session_start();
include('../config.php');

// For demo, get logged-in customer id
$customer_id = $_SESSION['user_id'] ?? 1;

// Fetch customer info
$customer_query = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = $customer_id");
$customer = mysqli_fetch_assoc($customer_query);

// Fetch all seed auctions (copy table from admin panel)
$auctions = mysqli_query($conn, "SELECT a.*, e.full_name 
                                FROM seed_auctions a 
                                LEFT JOIN employees e ON a.employee_id = e.employee_id 
                                ORDER BY a.auction_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seed Prices | Customer Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Montserrat', sans-serif;
    margin:0; padding:0;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('../assets/farm7.jpg') no-repeat center center/cover;
    color:#fff;
    animation: fadeBody 1s ease forwards;
}
@keyframes fadeBody { from {opacity:0;} to {opacity:1;} }

.header {
    background: #FFD700;
    padding: 25px 20px;
    text-align: center;
    color:#333;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
}
.header h1 { margin:0; font-size:2rem; }

.container {
    width:90%;
    max-width:1200px;
    margin:30px auto;
    background: rgba(255,255,255,0.2);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    padding: 20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.4);
    animation: fadeIn 1s ease forwards;
}
@keyframes fadeIn { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }

h2 {
    text-align:center;
    margin-bottom:20px;
    color:#FFD700;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
}

table {
    width:100%;
    border-collapse: collapse;
    background: rgba(255,255,255,0.1);
    border-radius: 12px;
    overflow: hidden;
}
th, td {
    padding:12px;
    border-bottom:1px solid rgba(255,255,255,0.3);
    text-align:center;
    color:#fff;
}
th {
    background:#FFD700;
    color:#333;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
}
tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition:0.3s;
}

.back-btn {
    text-align:center;
    margin-top:20px;
}
.back-btn a {
    color:#333;
    background:#FFD700;
    padding:10px 20px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    transition:0.3s;
}
.back-btn a:hover {
    background:#e6c200;
    transform: translateY(-2px) scale(1.03);
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

/* Responsive */
@media(max-width:600px){
    th, td { font-size:0.85rem; padding:8px; }
}
</style>
</head>
<body>

<div class="header">
    <h1>Seed Prices Dashboard</h1>
</div>

<div class="container">
    <h2>Available Seed Prices(Highest Price)</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Seed Name</th>
            <th>Price (₹)</th>
            <th>Auction Date</th>
            <th>Employee</th>
        </tr>
        <?php if(mysqli_num_rows($auctions) > 0): ?>
            <?php while($a = mysqli_fetch_assoc($auctions)): ?>
            <tr>
                <td><?= $a['auction_id'] ?></td>
                <td><?= htmlspecialchars($a['seed_name']) ?></td>
                <td><?= $a['price'] ?></td>
                <td><?= $a['auction_date'] ?></td>
                <td><?= htmlspecialchars($a['full_name'] ?? 'Unassigned') ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="5">No seed prices available.</td></tr>
        <?php endif; ?>
    </table>
</div>

<div class="back-btn">
    <a href="dashboard.php">⬅ Back to Dashboard</a>
</div>

</body>
</html>
