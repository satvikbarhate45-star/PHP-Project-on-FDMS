<?php
session_start();
include('../config.php');

$message = "";

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Check in customers table
    $query = "SELECT * FROM customers WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if ($password === $row['password']) { // plain password check (replace with password_verify for hashed)
            
            // Set session variables
            $_SESSION['user_role'] = 'customer';
            $_SESSION['user_id'] = $row['customer_id'];
            $_SESSION['user_name'] = $row['full_name'];

            // Insert login record into customer_login table
            $customer_id = $row['customer_id'];
            $farm_seed_type = $row['farm_available']; // assuming this is the seed chosen
            $login_date = date('Y-m-d H:i:s');

            $stmt = mysqli_prepare($conn, "INSERT INTO customer_login (customer_id, farm_seed_type, login_date) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "iss", $customer_id, $farm_seed_type, $login_date);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            // Redirect to dashboard
            header("Location: dashboard.php");
            exit;

        } else {
            $message = "❌ Invalid password!";
        }
    } else {
        $message = "❌ Email not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Login</title>
<style>
  /* Fade-in animation */
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  body {
    margin:0;
    padding:0;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('../assets/farm3.webp') no-repeat center center/cover;
    color:#fff;
    animation: fadeIn 1s ease forwards;
  }

  .login-box {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    padding: 40px 35px;
    border-radius: 15px;
    width: 360px;
    text-align:center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    animation: fadeIn 1.2s ease forwards;
  }

  .login-box h2 {
    margin-bottom:25px;
    font-size:2rem;
    text-shadow:2px 2px 6px rgba(0,0,0,0.5);
  }

  .login-box input {
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:10px;
    outline:none;
    font-size:1rem;
  }

  .login-btn {
    width:100%;
    padding:12px;
    margin-top:15px;
    background:#76b852;
    border:none;
    color:#fff;
    font-size:1.1rem;
    font-weight:bold;
    border-radius:10px;
    cursor:pointer;
    transition: transform 0.3s, background 0.3s, box-shadow 0.3s;
  }

  .login-btn:hover {
    background:#5aa33c;
    transform: translateY(-5px) scale(1.05);
    box-shadow:0 10px 25px rgba(0,0,0,0.4);
  }

  .error {
    margin-top:15px;
    color:#ffdddd;
    background: rgba(255,0,0,0.4);
    padding:10px;
    border-radius:8px;
    animation: fadeIn 0.8s ease;
  }

  .back-link a {
    display:inline-block;
    margin-top:20px;
    padding:10px 20px;
    background:#00BFFF;
    color:#fff;
    text-decoration:none;
    font-weight:bold;
    border-radius:10px;
    transition: transform 0.3s, background 0.3s, box-shadow 0.3s;
  }

  .back-link a:hover {
    background:#009acd;
    transform: translateY(-3px) scale(1.05);
    box-shadow:0 8px 20px rgba(0,0,0,0.3);
  }

  @media (max-width: 400px) {
    .login-box { width: 90%; padding: 30px 20px; }
    .login-box h2 { font-size:1.5rem; }
  }
</style>
</head>
<body>

<div class="login-box">
    <h2>Customer Login</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="login-btn">Login</button>
    </form>

    <?php if($message): ?>
        <div class="error"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="back-link">
        <a href="register.php">Register</a> | <a href="../index.php">⬅ Home</a>
    </div>
</div>

</body>
</html>
