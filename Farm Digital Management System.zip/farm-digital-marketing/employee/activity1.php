<?php
include('../config.php');

$message = "";

// Fetch employees for select dropdown
$employees = [];
$emp_query = "SELECT employee_id, full_name FROM employees ORDER BY full_name ASC";
$emp_result = mysqli_query($conn, $emp_query);
if ($emp_result) {
    while ($row = mysqli_fetch_assoc($emp_result)) {
        $employees[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = intval($_POST['employee_id']);
    $employee_name = mysqli_real_escape_string($conn, $_POST['employee_name']);
    $farm_seed_type = mysqli_real_escape_string($conn, $_POST['farm_seed_type']);
    $profit = floatval($_POST['profit']);
    $loss = floatval($_POST['loss']);
    $activity_date = $_POST['activity_date'];

    $insert_query = "INSERT INTO employee_activity (employee_id, employee_name, farm_seed_type, profit, loss, activity_date)
                     VALUES ($employee_id, '$employee_name', '$farm_seed_type', $profit, $loss, '$activity_date')";

    if (mysqli_query($conn, $insert_query)) {
        $message = "Activity added successfully!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Activity</title>
<style>
/* Body & Background */
body {
    margin:0;
    padding:0;
    font-family:'Segoe UI',sans-serif;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('../assets/farm2.jpg') no-repeat center center fixed;
    background-size: cover;
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:40px 20px;
}

/* Form Container */
.form-container {
    width:400px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(15px);
    padding:30px 40px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.5);
    animation: fadeIn 1s ease forwards;
}
@keyframes fadeIn { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }

.form-container h2 {
    text-align:center;
    margin-bottom:20px;
    color:#FFD700;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
}

.form-container input, .form-container select {
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:10px;
    outline:none;
    font-size:1rem;
}

/* Submit Button */
.submit-btn {
    width:100%;
    padding:12px;
    margin-top:10px;
    background:#FFD700;
    border:none;
    color:#000;
    font-size:1.1rem;
    font-weight:bold;
    border-radius:10px;
    cursor:pointer;
    transition:0.3s;
}
.submit-btn:hover {
    background:#e5c100;
    transform:translateY(-2px);
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

/* Message */
.message {
    text-align:center;
    margin-bottom:10px;
    font-weight:bold;
    color:#0f0;
}

/* Back Link */
.back-link {
    text-align:center;
    margin-top:15px;
}
.back-link a {
    color:#FFD700;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.back-link a:hover {
    text-decoration:underline;
}
</style>
</head>
<body>

<div class="form-container">
    <h2>📝 Add Activity</h2>

    <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <select name="employee_id" required>
            <option value="">-- Select Employee --</option>
            <?php foreach($employees as $emp): ?>
                <option value="<?php echo $emp['employee_id']; ?>"><?php echo $emp['full_name']; ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="employee_name" placeholder="Employee Name" required>
        <input type="text" name="farm_seed_type" placeholder="Farm Seed Type" required>
        <input type="number" step="0.01" name="profit" placeholder="Profit" required>
        <input type="number" step="0.01" name="loss" placeholder="Loss" required>
        <input type="date" name="activity_date" value="<?php echo date('Y-m-d'); ?>" required>
        <button type="submit" class="submit-btn">Add Activity</button>
    </form>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
