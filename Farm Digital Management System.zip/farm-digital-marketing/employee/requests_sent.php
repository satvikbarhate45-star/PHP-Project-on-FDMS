<?php
session_start();
include('../config.php');

$message = "";

// Get today's date
$today = date('Y-m-d');

// Fetch available customers for today
$customer_query = "SELECT * FROM customers WHERE created_at = '$today'";
$customer_result = mysqli_query($conn, $customer_query);

// Handle sending request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customer_id'])) {
    $employee_id = intval($_SESSION['user_id']); // logged-in employee
    $customer_id = intval($_POST['customer_id']);
    $request_date = date('Y-m-d H:i:s');

    // Insert into employee_requests table
    $insert_query = "INSERT INTO employee_requests (employee_id, customer_id, request_date)
                     VALUES ($employee_id, $customer_id, '$request_date')";
    if (mysqli_query($conn, $insert_query)) {
        $message = "Request sent successfully!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Send Requests to Customers</title>
<style>
body {
    margin:0; padding:0; font-family:'Segoe UI',sans-serif;
    min-height:100vh; background: linear-gradient(-45deg,#76b852,#8DC26F,#FF6F61,#00BFFF);
    background-size:400% 400%; animation: gradientBG 12s ease infinite; color:#fff;
}
@keyframes gradientBG { 0%{background-position:0% 50%;}50%{background-position:100% 50%;}100%{background-position:0% 50%;} }

.container { width:90%; max-width:900px; margin:50px auto; background: rgba(0,0,0,0.5); padding:20px; border-radius:15px; backdrop-filter: blur(8px); }
h2 { text-align:center; margin-bottom:20px; }

table { width:100%; border-collapse: collapse; margin-top:20px; }
table th, table td { padding:12px; border-bottom:1px solid rgba(255,255,255,0.3); text-align:left; }
table th { background: rgba(255,255,255,0.1); }
table tr:hover { background: rgba(255,255,255,0.1); }

button { padding:8px 15px; border:none; border-radius:6px; background:#FF6F61; color:#fff; font-weight:bold; cursor:pointer; transition:0.3s; }
button:hover { background:#e65c50; }

.message { text-align:center; margin-bottom:10px; font-weight:bold; color:#0f0; }
.back-link { text-align:center; margin-top:15px; }
.back-link a { color:#fff; text-decoration:none; font-weight:bold; }
.back-link a:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="container">
    <h2>Send Requests to Customers Available Today</h2>

    <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <table>
        <tr>
            <th>Customer Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Farm Seed</th>
            <th>Action</th>
        </tr>
        <?php if($customer_result && mysqli_num_rows($customer_result) > 0): ?>
            <?php while($customer = mysqli_fetch_assoc($customer_result)): ?>
                <tr>
                    <td><?php echo $customer['full_name']; ?></td>
                    <td><?php echo $customer['email']; ?></td>
                    <td><?php echo $customer['phone']; ?></td>
                    <td><?php echo $customer['farm_available']; ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="customer_id" value="<?php echo $customer['customer_id']; ?>">
                            <button type="submit">Send Request</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="5" style="text-align:center;">No customers available today</td></tr>
        <?php endif; ?>
    </table>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
