<?php
session_start();
include('../config.php'); // database connection

$message = '';

$farmTypes = ["Vegetables", "Fruits", "Grains", "Dairy", "Poultry", "Flowers", "Herbs", "Organic", "Others"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $username  = trim($_POST['username']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $farm_type = $_POST['farm_type'];
    $password  = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    if ($password !== $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        $hash_password = password_hash($password, PASSWORD_DEFAULT);

        $check = mysqli_query($conn, "SELECT * FROM employees WHERE username='$username'");
        if (mysqli_num_rows($check) > 0) {
            $message = "Username already taken!";
        } else {
            $insert = mysqli_query($conn, "INSERT INTO employees (full_name, username, email, phone, farm_type, password) 
                                           VALUES ('$full_name', '$username', '$email', '$phone', '$farm_type', '$hash_password')");
            if ($insert) {
                $message = "✅ Registration successful! You can now login.";
            } else {
                $message = "Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Registration</title>
<style>
  /* Body & background */
  body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', sans-serif;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
                url("../assets/farm3.webp") no-repeat center center fixed;
    background-size: cover;
    animation: fadeBody 1s ease forwards;
  }

  @keyframes fadeBody {
    from {opacity:0;}
    to {opacity:1;}
  }

  /* Container */
  .register-box {
    width: 420px;
    padding: 35px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    border-radius: 25px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    color: #fff;
    animation: slideUp 1s ease forwards;
  }

  @keyframes slideUp {
    from {transform: translateY(50px); opacity: 0;}
    to {transform: translateY(0); opacity: 1;}
  }

  .register-box h2 {
    color: #FFD700;
    margin-bottom: 25px;
    font-size: 1.8rem;
  }

  input, select {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border-radius: 10px;
    border: none;
    background: rgba(255,255,255,0.15);
    color: #fff;
    font-size: 1rem;
    outline: none;
  }

  select option {
    color: #000;
  }

  button {
    width: 100%;
    padding: 12px;
    margin-top: 15px;
    border: none;
    border-radius: 10px;
    background: #76b852;
    font-size: 1.1rem;
    font-weight: bold;
    color: #fff;
    cursor: pointer;
    transition: 0.3s;
  }

  button:hover {
    background: #5da843;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
  }

  .message {
    margin-top: 15px;
    font-weight: bold;
    color: #ff6f61;
  }

  .links {
    margin-top: 20px;
  }

  .links a {
    color: #FFD700;
    text-decoration: none;
    font-weight: bold;
    margin: 0 10px;
    transition: 0.3s;
  }

  .links a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>

<div class="register-box">
  <h2>📝 Employee Registration</h2>
  <form method="POST">
    <input type="text" name="full_name" placeholder="Full Name" required>
    <input type="text" name="username" placeholder="Username" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="phone" placeholder="Phone">
    
    <!-- Dynamic farm type dropdown -->
    <select name="farm_type" required>
      <option value="">-- Select Farm Type --</option>
      <?php foreach($farmTypes as $type): ?>
        <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
      <?php endforeach; ?>
    </select>
    
    <input type="password" name="password" placeholder="Password" required>
    <input type="password" name="confirm_password" placeholder="Confirm Password" required>
    <button type="submit">Register</button>
  </form>

  <?php if($message): ?>
    <div class="message"><?php echo $message; ?></div>
  <?php endif; ?>

  <div class="links">
    <a href="login.php">⬅ Back to Login</a>
    <a href="../index.php">🏠 Home</a>
  </div>
</div>

</body>
</html>
