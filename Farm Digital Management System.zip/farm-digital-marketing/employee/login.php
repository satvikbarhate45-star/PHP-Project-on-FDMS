<?php
session_start();
include('../config.php'); // database connection

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Check if employee exists
    $query = "SELECT * FROM employees WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) === 1) {
        $employee = mysqli_fetch_assoc($result);
        // Verify password
        if (password_verify($password, $employee['password'])) {
            $_SESSION['user_role'] = "employee";
            $_SESSION['employee_id'] = $employee['employee_id'];
            $_SESSION['employee_name'] = $employee['full_name'];
            $_SESSION['employee_username'] = $employee['username'];
            header("Location: dashboard.php");
            exit;
        } else {
            $message = "❌ Invalid password!";
        }
    } else {
        $message = "❌ Employee not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Login</title>
<style>
body {
    margin:0;
    padding:0;
    font-family:'Segoe UI',sans-serif;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3)), url("../assets/farm3.webp") no-repeat center center fixed;
    background-size:cover;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn { from {opacity:0;} to {opacity:1;} }

.login-box {
    width:360px;
    padding:30px;
    background:rgba(255,255,255,0.08);
    border-radius:20px;
    backdrop-filter:blur(10px);
    text-align:center;
    color:#fff;
    box-shadow:0 10px 25px rgba(0,0,0,0.5);
    animation: slideUp 0.9s ease forwards;
}

@keyframes slideUp { from {transform:translateY(40px); opacity:0;} to {transform:translateY(0); opacity:1;} }

.login-box h2 { margin-bottom:20px; font-size:1.6rem; color:#FFD700; }

input { width:100%; padding:12px; margin:10px 0; border-radius:8px; border:none; background:rgba(255,255,255,0.15); color:#fff; font-size:1rem; outline:none; }
input::placeholder { color:#ddd; }

button { width:100%; padding:12px; margin-top:15px; border:none; border-radius:8px; background:#76b852; color:#fff; font-size:1.1rem; font-weight:bold; cursor:pointer; transition:0.3s; }
button:hover { background:#5da843; box-shadow:0 5px 15px rgba(0,0,0,0.3); }

.error { margin-top:15px; color:#ff6f61; font-weight:bold; }

.links {
    margin-top:15px;
    display:flex;
    justify-content:space-between;
    font-size:0.9rem;
    flex-wrap:wrap;
}

.links a { color:#FFD700; text-decoration:none; font-weight:bold; margin:5px 0; transition:0.3s; }
.links a:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="login-box">
    <h2>👨‍🌾 Employee Login</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Enter Username" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <button type="submit">Login</button>
    </form>

    <?php if ($message): ?>
        <div class="error"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="links">
        <a href="register.php">📝 Register</a>
        <a href="forgot_password.php">🔑 Forgot Password?</a>
        <a href="../index.php">🏠 Home</a>
    </div>
</div>

</body>
</html>
