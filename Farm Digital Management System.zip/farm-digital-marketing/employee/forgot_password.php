<?php
session_start();
include('../config.php'); // DB connection

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier']); // username or email
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    if ($new_password !== $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        $hash_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Check if user exists
        $query = "SELECT * FROM employees WHERE username='$identifier' OR email='$identifier'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            // Update password
            $update = mysqli_query($conn, "UPDATE employees SET password='$hash_password' WHERE username='$identifier' OR email='$identifier'");
            if ($update) {
                $message = "✅ Password reset successfully! You can now login.";
            } else {
                $message = "Error updating password: " . mysqli_error($conn);
            }
        } else {
            $message = "No employee found with that username or email!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password</title>
<style>
body {
    margin:0;
    padding:0;
    font-family: 'Segoe UI', sans-serif;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
                url("../assets/farm3.webp") no-repeat center center fixed;
    background-size:cover;
    animation: fadeBody 1s ease forwards;
}

@keyframes fadeBody { from {opacity:0;} to {opacity:1;} }

.forgot-box {
    width:400px;
    padding:35px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    border-radius:25px;
    text-align:center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    color:#fff;
    animation: slideUp 1s ease forwards;
}

@keyframes slideUp { from {transform:translateY(50px);opacity:0;} to {transform:translateY(0);opacity:1;} }

.forgot-box h2 { color:#FFD700; margin-bottom:25px; font-size:1.8rem; }

input {
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:10px;
    border:none;
    background: rgba(255,255,255,0.15);
    color:#fff;
    font-size:1rem;
    outline:none;
}

input::placeholder { color:#ddd; }

button {
    width:100%;
    padding:12px;
    margin-top:15px;
    border:none;
    border-radius:10px;
    background:#76b852;
    font-size:1.1rem;
    font-weight:bold;
    color:#fff;
    cursor:pointer;
    transition:0.3s;
}

button:hover {
    background:#5da843;
    transform:translateY(-2px);
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

.message { margin-top:15px; font-weight:bold; color:#ff6f61; }

.links { margin-top:20px; }
.links a {
    color:#FFD700;
    text-decoration:none;
    font-weight:bold;
    margin:0 10px;
    transition:0.3s;
}
.links a:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="forgot-box">
    <h2>🔑 Forgot Password</h2>
    <form method="POST">
        <input type="text" name="identifier" placeholder="Enter Username or Email" required>
        <input type="password" name="new_password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
        <button type="submit">Reset Password</button>
    </form>

    <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="links">
        <a href="login.php">⬅ Back to Login</a>
        <a href="../index.php">🏠 Home</a>
    </div>
</div>

</body>
</html>
