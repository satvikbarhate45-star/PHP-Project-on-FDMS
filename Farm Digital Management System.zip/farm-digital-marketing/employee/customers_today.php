<?php
session_start();
include('../config.php');

// Redirect if not logged in as admin or employee
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin','employee'])) {
    header("Location: ../index.php");
    exit;
}

// Handle deletion
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM customer_login WHERE login_id = $delete_id");
    header("Location: customers_today.php"); // redirect to refresh table
    exit;
}

$current_date = date("Y-m-d");

// Fetch latest login for each customer today
$query = "
SELECT cl.login_id, c.customer_id, c.full_name, c.email, c.phone, cl.farm_seed_type, cl.login_date
FROM customer_login cl
JOIN customers c ON c.customer_id = cl.customer_id
INNER JOIN (
    SELECT customer_id, MAX(login_date) AS latest_login
    FROM customer_login
    WHERE DATE(login_date) = '$current_date'
    GROUP BY customer_id
) AS latest ON cl.customer_id = latest.customer_id AND cl.login_date = latest.latest_login
ORDER BY cl.login_date DESC
";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Today's Customers</title>
<style>
/* Body & Background */
body {
    margin:0;
    padding:0;
    font-family:'Segoe UI',sans-serif;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('../assets/farm2.jpg') no-repeat center center fixed;
    background-size: cover;
    color:#fff;
    display:flex;
    flex-direction:column;
    align-items:center;
    padding:40px 20px;
    animation: fadeBody 1s ease forwards;
}

@keyframes fadeBody { from {opacity:0;} to {opacity:1;} }

/* Container */
.container {
    width: 95%;
    max-width:1200px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(15px);
    padding:30px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.5);
    animation: fadeContainer 1s ease forwards;
}

@keyframes fadeContainer {
    from {opacity:0; transform:translateY(20px);}
    to {opacity:1; transform:translateY(0);}
}

/* Heading */
h2 {
    text-align:center;
    margin-bottom:30px;
    font-size:2rem;
    color:#FFD700;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.5);
}

/* Table Styling */
table {
    width:100%;
    border-collapse: collapse;
    border-radius:10px;
    overflow:hidden;
}

th, td {
    padding:12px;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,0.3);
    color:#fff;
}

th {
    background: rgba(0,0,0,0.3);
    font-weight:bold;
}

tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition:0.3s;
}

/* Delete button */
.delete-btn {
    padding:6px 12px;
    background:#FF4500;
    color:#fff;
    border:none;
    border-radius:6px;
    cursor:pointer;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.delete-btn:hover {
    background:#e63b00;
}

/* Back Button */
.back-link {
    text-align:center;
    margin-top:25px;
}
.back-link a {
    display:inline-block;
    background:#FFD700;
    color:#000;
    padding:12px 25px;
    border-radius:10px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.back-link a:hover {
    background:#e5c100;
}

/* Responsive Table */
@media(max-width:768px){
    table, thead, tbody, th, td, tr { display:block; }
    th { position:absolute; top:-9999px; left:-9999px; }
    td { border:none; position:relative; padding-left:50%; margin-bottom:10px; }
    td:before { 
        position:absolute; 
        top:12px; 
        left:12px; 
        width:45%; 
        padding-right:10px; 
        white-space: nowrap; 
        font-weight:bold; 
        content: attr(data-label);
        color:#FFD700;
    }
}
</style>
</head>
<body>

<div class="container">
    <h2>👥 Customers Logged In Today (<?php echo $current_date; ?>)</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Farm Seed</th>
                <th>Login At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td data-label="ID"><?= $row['customer_id']; ?></td>
                        <td data-label="Full Name"><?= htmlspecialchars($row['full_name']); ?></td>
                        <td data-label="Email"><?= htmlspecialchars($row['email']); ?></td>
                        <td data-label="Phone"><?= htmlspecialchars($row['phone']); ?></td>
                        <td data-label="Farm Seed"><?= htmlspecialchars($row['farm_seed_type']); ?></td>
                        <td data-label="Login At"><?= date('H:i:s', strtotime($row['login_date'])); ?></td>
                        <td data-label="Action">
                            <a href="customers_today.php?delete_id=<?= $row['login_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;">No customers logged in today.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
