<?php
session_start();
include('../config.php');

// Check login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee') {
    header("Location: login.php");
    exit;
}

$employee_id = $_SESSION['employee_id'];

// Fetch employee info
$employee_query = "SELECT * FROM employees WHERE employee_id='$employee_id'";
$employee_result = mysqli_query($conn, $employee_query);
$employee = mysqli_fetch_assoc($employee_result);

// Count pending requests
$pending_query = "SELECT COUNT(*) as pending_count FROM employee_requests WHERE employee_id='$employee_id' AND status='Pending'";
$pending_result = mysqli_query($conn, $pending_query);
$pending_count = mysqli_fetch_assoc($pending_result)['pending_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Dashboard</title>
<style>
body {
    margin:0;
    padding:0;
    font-family:'Segoe UI',sans-serif;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:flex-start;
    background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url("../assets/farm2.jpg") no-repeat center center fixed;
    background-size:cover;
    color:#fff;
    overflow-x:hidden;
    animation: fadeBody 1s ease forwards;
}

@keyframes fadeBody { 
    from {opacity:0;} 
    to {opacity:1;} 
}

.container {
    width: 90%;
    max-width: 950px;
    margin-top: 50px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    animation: containerFade 1s ease forwards;
}
@keyframes containerFade {
    from { opacity:0; transform:translateY(20px);}
    to { opacity:1; transform:translateY(0);}
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    padding: 25px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    text-align: center;
    transition: transform 0.3s, box-shadow 0.3s;
    cursor: pointer;
    position: relative;
    animation: cardFade 0.8s ease forwards;
}
.card:hover {
    transform: translateY(-10px) scale(1.03);
    box-shadow: 0 15px 40px rgba(0,0,0,0.6);
}
@keyframes cardFade {
    from { opacity:0; transform:translateY(20px);}
    to { opacity:1; transform:translateY(0);}
}

.card h3 { 
    margin-bottom: 15px; 
    color: #FFD700; 
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}
.card p { 
    margin: 5px 0; 
    font-size: 1rem; 
    color: #fff;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.4);
}

.logout {
    position: absolute;
    top: 20px;
    right: 30px;
    padding: 10px 20px;
    background: #FF6F61;
    border-radius: 8px;
    text-decoration: none;
    color: #fff;
    font-weight: bold;
    transition: 0.3s;
    animation: fadeIn 1s ease forwards;
}
.logout:hover { background: #e65c50; }

.welcome {
    grid-column: 1/-1;
    text-align:center;
    margin-bottom:20px;
    font-size:1.5rem;
    color:#FFD700;
    animation: fadeInUp 1s ease forwards;
}
@keyframes fadeIn { from {opacity:0;} to {opacity:1;} }
@keyframes fadeInUp { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }

/* Pending request badge */
.badge {
    position:absolute;
    top:15px;
    right:20px;
    background:#FFD700;
    color:#000;
    font-weight:bold;
    padding:5px 10px;
    border-radius:50%;
    font-size:0.9rem;
    box-shadow:0 2px 10px rgba(0,0,0,0.5);
    animation: pulse 1.5s infinite;
}
@keyframes pulse {
    0% { transform: scale(1); box-shadow:0 2px 10px rgba(0,0,0,0.5); }
    50% { transform: scale(1.2); box-shadow:0 4px 15px rgba(0,0,0,0.7); }
    100% { transform: scale(1); box-shadow:0 2px 10px rgba(0,0,0,0.5); }
}
</style>
</head>
<body>

<a href="logout.php" class="logout">Logout</a>

<div class="container">
    <div class="welcome">
        👋 Welcome, <?php echo htmlspecialchars($employee['full_name']); ?>!
    </div>

    <!-- Employee Info -->
    <div class="card">
        <h3>Farm Type</h3>
        <p><?php echo htmlspecialchars($employee['farm_type']); ?></p>
    </div>

    <div class="card">
        <h3>Email</h3>
        <p><?php echo htmlspecialchars($employee['email']); ?></p>
    </div>

    <div class="card">
        <h3>Phone</h3>
        <p><?php echo htmlspecialchars($employee['phone']); ?></p>
    </div>

    <!-- Visit Dates -->
    <div class="card" onclick="location.href='visit_dates.php';">
        <h3>Visit Dates & Availability</h3>
        <p>Click to view details</p>
    </div>

    <!-- Customers Available Today -->
    <div class="card" onclick="location.href='customers_today.php';">
        <h3>Customers Available Today</h3>
        <p>Click to view details</p>
    </div>

    <div class="card" onclick="location.href='activity1.php';">
        <h3>Add Today's Activity</h3>
        <p>Click to view details</p>
    </div>

</div>

</body>
</html>
