<?php
session_start();
include('../config.php');

$message = "";

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Check in customers table
    $query = "SELECT * FROM customers WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);

        // Plain password check for demo
        if ($password === $row['password']) {
            // Store session
            $_SESSION['customer_id'] = $row['customer_id'];
            $_SESSION['customer_name'] = $row['full_name'];
            $_SESSION['customer_email'] = $row['email'];
            $_SESSION['customer_farm'] = $row['farm_available'];

            // Insert login record in customer_login table
            $customer_id = $row['customer_id'];
            $full_name = $row['full_name'];
            $farm_available = $row['farm_available'];
            $insert_login = "INSERT INTO customer_login (customer_id, full_name, email, farm_available) 
                             VALUES ('$customer_id','$full_name','$email','$farm_available')";
            mysqli_query($conn, $insert_login);

            $message = "Login successful!";
        } else {
            $message = "Invalid password!";
        }
    } else {
        $message = "Email not registered!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Login Details</title>
<style>
body { margin:0; padding:0; font-family:'Segoe UI',sans-serif; display:flex; justify-content:center; align-items:center; min-height:100vh;
       background: linear-gradient(-45deg,#FF6F61,#FFD194,#76b852,#00BFFF); background-size:400% 400%; animation: gradientBG 12s ease infinite; color:#fff; }
@keyframes gradientBG {0%{background-position:0% 50%;}50%{background-position:100% 50%;}100%{background-position:0% 50%;}}

.container { background: rgba(255,255,255,0.1); backdrop-filter: blur(12px); padding:30px 40px; border-radius:15px; width:450px; box-shadow:0 8px 25px rgba(0,0,0,0.3); animation:fadeIn 1s ease; }
@keyframes fadeIn { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }

h2 { text-align:center; margin-bottom:20px; text-shadow:1px 1px 3px rgba(0,0,0,0.4); }
table { width:100%; border-collapse:collapse; margin-top:15px; }
th, td { padding:12px; text-align:left; border-bottom:1px solid rgba(255,255,255,0.2); }
th { background: rgba(255,255,255,0.2); }
.back-link { text-align:center; margin-top:20px; }
.back-link a { color:#fff; text-decoration:none; font-weight:bold; transition:0.3s; }
.back-link a:hover { text-decoration:underline; }
.message { text-align:center; font-weight:bold; margin-bottom:10px; }
.success { color:#0f0; }
.error { color:#ffdddd; }
</style>
</head>
<body>

<div class="container">
    <h2>Customer Login Details</h2>

    <?php if($message): ?>
        <div class="message <?= strpos($message,'successful')!==false ? 'success':'error' ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_SESSION['customer_id'])): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Farm Available</th>
            </tr>
            <tr>
                <td><?php echo $_SESSION['customer_id']; ?></td>
                <td><?php echo $_SESSION['customer_name']; ?></td>
                <td><?php echo $_SESSION['customer_email']; ?></td>
                <td>
                    <?php 
                    $query = "SELECT phone FROM customers WHERE customer_id='".$_SESSION['customer_id']."'";
                    $res = mysqli_query($conn, $query);
                    $phone_row = mysqli_fetch_assoc($res);
                    echo $phone_row['phone'];
                    ?>
                </td>
                <td><?php echo $_SESSION['customer_farm']; ?></td>
            </tr>
        </table>
    <?php endif; ?>

    <div class="back-link">
        <a href="dashboard.php">⬅ Go to Dashboard</a> | <a href="../index.php">Home</a>
    </div>
</div>

</body>
</html>
