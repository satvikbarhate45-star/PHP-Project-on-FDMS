<?php
session_start();
include('../config.php');

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Handle delete request
if(isset($_GET['delete_id'])){
    $delete_id = intval($_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM employee_activity WHERE activity_id='$delete_id'");
    header("Location: activity_history.php");
    exit;
}

// Fetch all employee activity
$activity_query = "
SELECT activity_id, employee_id, employee_name, farm_seed_type, profit, loss, activity_date
FROM employee_activity
ORDER BY activity_date DESC
";

$activity_result = mysqli_query($conn, $activity_query);
$activities = mysqli_fetch_all($activity_result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Activity History</title>
<style>
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    color:#fff;
    min-height:100vh;
    padding:20px;

    /* Farm-style background */
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url("../assets/tractor123.jpg") no-repeat center center fixed;
    background-size: cover;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    padding: 20px;
    opacity: 0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}

@keyframes slideIn {
    from { opacity:0; transform: translateY(50px); }
    to { opacity:1; transform: translateY(0); }
}

h2 {
    text-align:center;
    margin-bottom: 20px;
    color:#FFD700;
    font-size:2rem;
    text-shadow:1px 1px 4px rgba(0,0,0,0.7);
}

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 900px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 12px;
}

th, td {
    padding: 12px 15px;
    border-bottom: 1px solid rgba(255,255,255,0.2);
    text-align: left;
}

th {
    background: rgba(255,255,255,0.2);
    font-weight:bold;
}

tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition: 0.2s;
}

.profit { color: #28a745; font-weight:bold; }
.loss { color: #dc3545; font-weight:bold; }

.action-btn {
    padding:5px 10px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    font-weight:bold;
    color:#fff;
    text-decoration:none;
    margin-right:5px;
    transition:0.3s;
}

.edit-btn { background:#FFD700; color:#000; }
.edit-btn:hover { background:#e6c200; }

.delete-btn { background:#dc3545; }
.delete-btn:hover { background:#b21f2d; }

.back-btn {
    display:inline-block;
    margin-top:20px;
    padding:10px 20px;
    background:#FF6F61;
    border-radius:8px;
    text-decoration:none;
    color:#fff;
    font-weight:bold;
    transition:0.3s;
}
.back-btn:hover { background:#e65c50; box-shadow:0 5px 15px rgba(0,0,0,0.3); }
</style>
</head>
<body>

<div class="container">
    <h2>Employee Activity History</h2>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Farm Seed Type</th>
                    <th>Profit</th>
                    <th>Loss</th>
                    <th>Activity Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($activities): ?>
                    <?php foreach($activities as $act): ?>
                        <tr>
                            <td><?php echo $act['activity_id']; ?></td>
                            <td><?php echo $act['employee_id']; ?></td>
                            <td><?php echo htmlspecialchars($act['employee_name']); ?></td>
                            <td><?php echo htmlspecialchars($act['farm_seed_type']); ?></td>
                            <td class="profit"><?php echo number_format($act['profit'],2); ?></td>
                            <td class="loss"><?php echo number_format($act['loss'],2); ?></td>
                            <td><?php echo date('d-m-Y', strtotime($act['activity_date'])); ?></td>
                            <td>
                                <a href="edit_activity.php?activity_id=<?php echo $act['activity_id']; ?>" class="action-btn edit-btn">Edit</a>
                                <a href="activity_history.php?delete_id=<?php echo $act['activity_id']; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure to delete this activity?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8" style="text-align:center;">No activity found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <a href="employees.php" class="back-btn">⬅ Back to Employees</a>
</div>

</body>
</html>
