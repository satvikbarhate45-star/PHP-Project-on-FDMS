<?php
session_start();
include('../config.php');

// Allow only admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== "admin") {
    header("Location: login.php");
    exit;
}

// Handle adding new available seeds
if (isset($_POST['add_seed'])) {
    $customer_id = $_POST['customer_id'];
    $seed_name = trim($_POST['seed_name']);
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    if (!empty($seed_name) && !empty($quantity) && !empty($price)) {
        $insert = "INSERT INTO farm_available (customer_id, seed_name, quantity, price) 
                   VALUES ('$customer_id', '$seed_name', '$quantity', '$price')";
        mysqli_query($conn, $insert);
    }
}

// Fetch all customers
$customers = mysqli_query($conn, "SELECT customer_id, full_name FROM customers");

// Fetch all farming available records
$seeds = mysqli_query($conn, "SELECT fa.*, c.full_name FROM farm_available fa
                             LEFT JOIN customers c ON fa.customer_id = c.customer_id
                             ORDER BY fa.seed_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Farming Available | Admin Panel</title>
<style>
body {
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#11998e,#38ef7d);
    color:#fff;
    min-height:100vh;
}
.container {
    width:90%;
    max-width:1200px;
    margin:30px auto;
    background: rgba(255,255,255,0.1);
    padding:30px;
    border-radius:15px;
    box-shadow:0 8px 20px rgba(0,0,0,0.3);
    backdrop-filter: blur(10px);
}
h2 {
    text-align:center;
    margin-bottom:20px;
}
form {
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap:15px;
    margin-bottom:30px;
}
form input, form select, form button {
    padding:10px;
    border:none;
    border-radius:8px;
    outline:none;
    font-size:1rem;
}
form select, form input {
    width:100%;
}
form button {
    background:#004d40;
    color:#fff;
    cursor:pointer;
    font-weight:bold;
    transition:0.3s;
}
form button:hover {
    background:#00796b;
}
table {
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}
th, td {
    padding:10px;
    border-bottom:1px solid rgba(255,255,255,0.3);
    text-align:center;
    color:#fff;
}
th {
    background: rgba(255,255,255,0.2);
}
tr:hover {
    background: rgba(255,255,255,0.2);
}
.back-btn {
    text-align:center;
    margin-top:20px;
}
.back-btn a {
    color:#fff;
    background:#ff6f61;
    padding:10px 20px;
    border-radius:8px;
    text-decoration:none;
    transition:0.3s;
}
.back-btn a:hover {
    background:#e55b50;
}
</style>
</head>
<body>

<div class="container">
<h2>🌱 Farming Available</h2>

<form method="POST">
    <select name="customer_id" required>
        <option value="">Select Customer</option>
        <?php while($c = mysqli_fetch_assoc($customers)): ?>
            <option value="<?= $c['customer_id'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
        <?php endwhile; ?>
    </select>
    <input type="text" name="seed_name" placeholder="Seed Name" required>
    <input type="number" name="quantity" placeholder="Quantity (kg)" required>
    <input type="number" step="0.01" name="price" placeholder="Price (₹)" required>
    <button type="submit" name="add_seed">➕ Add Seed</button>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Seed Name</th>
            <th>Quantity (kg)</th>
            <th>Price (₹)</th>
        </tr>
    </thead>
    <tbody>
        <?php if(mysqli_num_rows($seeds) > 0): ?>
            <?php while($s = mysqli_fetch_assoc($seeds)): ?>
                <tr>
                    <td><?= $s['seed_id'] ?></td>
                    <td><?= htmlspecialchars($s['full_name']) ?></td>
                    <td><?= htmlspecialchars($s['seed_name']) ?></td>
                    <td><?= $s['quantity'] ?></td>
                    <td><?= $s['price'] ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="5">No seeds available yet.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="back-btn">
    <a href="dashboard.php">⬅ Back to Dashboard</a>
</div>
</div>

</body>
</html>
