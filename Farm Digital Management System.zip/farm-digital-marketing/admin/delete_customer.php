<?php
session_start();
include('../config.php');

// Only allow admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Check if customer ID is provided
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $customer_id = intval($_GET['id']);

    // Delete customer from database
    $delete_query = "DELETE FROM customers WHERE customer_id = $customer_id";
    if (mysqli_query($conn, $delete_query)) {
        $_SESSION['message'] = "Customer deleted successfully!";
    } else {
        $_SESSION['message'] = "Error deleting customer: " . mysqli_error($conn);
    }
} else {
    $_SESSION['message'] = "Invalid customer ID!";
}

// Redirect back to customer registration page
header("Location: customer_registration.php");
exit;
