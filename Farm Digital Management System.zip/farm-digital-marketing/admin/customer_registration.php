<?php
session_start();
include('../config.php');

// Redirect if not admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Fetch all registered customers
$query = "SELECT * FROM customers ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registered Customers</title>
<style>
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    color:#fff;
    min-height:100vh;
    padding:20px;

    /* Farm-style background */
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url("../assets/tractor123.jpg") no-repeat center center fixed;
    background-size: cover;
}

.container {
    width: 95%; max-width: 1200px;
    margin: 40px auto;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    opacity: 0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}

@keyframes slideIn {
    from { opacity:0; transform: translateY(50px); }
    to { opacity:1; transform: translateY(0); }
}

h2 {
    text-align:center;
    margin-bottom:20px;
    color:#FFD700;
    font-size:2rem;
    text-shadow:1px 1px 4px rgba(0,0,0,0.7);
}

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 800px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 12px;
}

th, td {
    padding: 12px 15px;
    border-bottom: 1px solid rgba(255,255,255,0.2);
    text-align: left;
}

th {
    background: rgba(255,255,255,0.2);
    font-weight:bold;
}

tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition: 0.2s;
}

.action-btn {
    padding:6px 12px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-weight:bold;
    transition:0.3s;
}

.edit { background:#FF6F61; color:#fff; }
.edit:hover { background:#e65c50; }

.delete { background:#dc3545; color:#fff; }
.delete:hover { background:#b21f2d; }

.back-link {
    text-align:center;
    margin-top:20px;
}

.back-link a {
    color:#fff;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}

.back-link a:hover {
    text-decoration:underline;
}
</style>
<script>
function confirmDelete(customerName) {
    return confirm("Are you sure you want to delete " + customerName + "?");
}
</script>
</head>
<body>

<div class="container">
    <h2>Registered Customers</h2>
    <div class="table-container">
    <?php if(mysqli_num_rows($result) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Farm Available</th>
                    <th>Registered At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['customer_id']; ?></td>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                    <td><?php echo htmlspecialchars($row['farm_available']); ?></td>
                    <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                    <td>
                        <a class="action-btn edit" href="edit_customer.php?id=<?php echo $row['customer_id']; ?>">Edit</a>
                        <a class="action-btn delete" href="delete_customer.php?id=<?php echo $row['customer_id']; ?>" onclick="return confirmDelete('<?php echo $row['full_name']; ?>')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align:center; font-weight:bold;">No registered customers yet.</p>
    <?php endif; ?>
    </div>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
