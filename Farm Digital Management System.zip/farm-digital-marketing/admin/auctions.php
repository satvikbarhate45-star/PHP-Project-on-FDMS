<?php
session_start();
include('../config.php');

// Only admin access
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== "admin") {
    header("Location: login.php");
    exit;
}

// ADD AUCTION
if (isset($_POST['add_auction'])) {
    $seed_name = trim($_POST['seed_name']);
    $price = $_POST['price'];
    $auction_date = $_POST['auction_date'];
    $employee_id = $_POST['employee_id'];

    if (!empty($seed_name) && !empty($price) && !empty($auction_date)) {
        $insert = "INSERT INTO seed_auctions (seed_name, price, auction_date, employee_id)
                   VALUES ('$seed_name', '$price', '$auction_date', '$employee_id')";
        mysqli_query($conn, $insert);
    }
}

// DELETE AUCTION
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM seed_auctions WHERE auction_id=$id");
    header("Location: auctions.php");
    exit;
}

// EDIT AUCTION
if (isset($_POST['edit_auction'])) {
    $id = $_POST['auction_id'];
    $seed_name = $_POST['seed_name'];
    $price = $_POST['price'];
    $auction_date = $_POST['auction_date'];
    $employee_id = $_POST['employee_id'];

    $update = "UPDATE seed_auctions 
               SET seed_name='$seed_name', price='$price', auction_date='$auction_date', employee_id='$employee_id' 
               WHERE auction_id=$id";
    mysqli_query($conn, $update);
    header("Location: auctions.php");
    exit;
}

// Fetch all auctions and employees
$auctions = mysqli_query($conn, "SELECT a.*, e.full_name FROM seed_auctions a 
                                 LEFT JOIN employees e ON a.employee_id = e.employee_id 
                                 ORDER BY a.auction_date DESC");
$employees = mysqli_query($conn, "SELECT employee_id, full_name FROM employees");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Seed Auctions | Admin Panel</title>
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    min-height: 100vh;
    color: #fff;
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)), 
                url("../assets/tractor123.jpg") no-repeat center center fixed;
    background-size: cover;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 30px auto;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    opacity:0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}

@keyframes slideIn {
    from {opacity:0; transform: translateY(50px);}
    to {opacity:1; transform: translateY(0);}
}

h2 {
    text-align:center;
    margin-bottom:20px;
    font-size:2rem;
    text-shadow:1px 1px 4px rgba(0,0,0,0.6);
}

form {
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-bottom: 30px;
}

input, select, button {
    padding: 10px;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    outline: none;
}

input, select {
    background: rgba(255,255,255,0.8);
    color: #333;
}

button {
    background: #FF6F61;
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition: 0.3s;
}

button:hover {
    background:#e65b50;
    transform: scale(1.05);
}

.table-container {
    overflow-x:auto;
}

table {
    width:100%;
    border-collapse: collapse;
    min-width: 800px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(8px);
    border-radius:12px;
}

th, td {
    padding:10px;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,0.2);
}

th {
    background: rgba(255,255,255,0.2);
}

tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition: 0.2s;
}

a.action-btn {
    padding: 5px 12px;
    border-radius: 6px;
    color: white;
    text-decoration: none;
    font-weight: bold;
    margin: 0 5px;
}

a.edit { background: #00c851; }
a.delete { background: #ff4444; }

a.edit:hover { background: #009e42; }
a.delete:hover { background: #cc0000; }

.back-btn {
    text-align: center;
    margin-top: 20px;
}

.back-btn a {
    color: #fff;
    background: #333;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.3s;
}

.back-btn a:hover {
    background: #555;
}
</style>
</head>
<body>

<div class="container">
  <h2>🌾 Seed Auctions Management</h2>

  <form method="POST">
    <input type="text" name="seed_name" placeholder="Seed Name" required>
    <input type="number" step="0.01" name="price" placeholder="Price (₹)" required>
    <input type="date" name="auction_date" value="<?= date('Y-m-d'); ?>" required>
    <select name="employee_id" required>
      <option value="">Select Employee</option>
      <?php while($emp = mysqli_fetch_assoc($employees)): ?>
        <option value="<?= $emp['employee_id'] ?>"><?= $emp['full_name'] ?></option>
      <?php endwhile; ?>
    </select>
    <button type="submit" name="add_auction">➕ Add Auction</button>
  </form>

  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Seed Name</th>
          <th>Price (₹)</th>
          <th>Date</th>
          <th>Employee</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while($a = mysqli_fetch_assoc($auctions)): ?>
        <tr>
          <td><?= $a['auction_id'] ?></td>
          <td><?= htmlspecialchars($a['seed_name']) ?></td>
          <td><?= $a['price'] ?></td>
          <td><?= $a['auction_date'] ?></td>
          <td><?= $a['full_name'] ?? 'Unassigned' ?></td>
          <td>
            <a href="edit_auction.php?id=<?= $a['auction_id'] ?>" class="action-btn edit">Edit</a>
            <a href="?delete=<?= $a['auction_id'] ?>" class="action-btn delete" onclick="return confirm('Delete this record?')">Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="back-btn">
  <a href="dashboard.php">⬅ Back to Dashboard</a>
</div>

</body>
</html>
