<?php
session_start();
include('../config.php');

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Get employee ID from URL
if(!isset($_GET['employee_id'])){
    header("Location: manage_employees.php");
    exit;
}

$employee_id = intval($_GET['employee_id']);
$message = "";

// Fetch employee info
$query = "SELECT * FROM employees WHERE employee_id='$employee_id'";
$result = mysqli_query($conn, $query);
$employee = mysqli_fetch_assoc($result);

if(!$employee){
    header("Location: manage_employees.php");
    exit;
}

// Example farm types
$farm_types = ['Vegetables','Fruits','Grains','Dairy','Poultry','Flowers'];

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $full_name = trim($_POST['full_name']);
    $username  = trim($_POST['username']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $farm_type = trim($_POST['farm_type']);

    // Optional password update
    if(!empty($_POST['password'])){
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update_query = "UPDATE employees SET full_name='$full_name', username='$username', email='$email', phone='$phone', farm_type='$farm_type', password='$password' WHERE employee_id='$employee_id'";
    } else {
        $update_query = "UPDATE employees SET full_name='$full_name', username='$username', email='$email', phone='$phone', farm_type='$farm_type' WHERE employee_id='$employee_id'";
    }

    $update_result = mysqli_query($conn, $update_query);
    if($update_result){
        header("Location: manage_employees.php");
        exit;
    } else {
        $message = "Error updating employee. Try again!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Employee</title>
<style>
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background: linear-gradient(135deg,#1f1c2c,#928dab);
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:flex-start;
    min-height:100vh;
    padding:50px 20px;
}

.form-container {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(15px);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    width: 400px;
    animation: fadeIn 1s ease forwards;
}

h2 {
    text-align:center;
    margin-bottom:25px;
    color:#FFD700;
    font-size:2rem;
    text-shadow:1px 1px 4px rgba(0,0,0,0.5);
}

input, select {
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:10px;
    outline:none;
    font-size:1rem;
}

button {
    width:100%;
    padding:12px;
    margin-top:10px;
    background:#FF6F61;
    border:none;
    border-radius:10px;
    font-size:1.1rem;
    font-weight:bold;
    color:#fff;
    cursor:pointer;
    transition:0.3s;
}

button:hover {
    background:#e65c50;
    transform:translateY(-2px);
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

.error {
    background: rgba(255,0,0,0.4);
    padding:8px;
    border-radius:6px;
    margin-bottom:10px;
    text-align:center;
}

.back-btn {
    display:inline-block;
    margin-top:20px;
    padding:8px 15px;
    background:#FFD700;
    border-radius:8px;
    text-decoration:none;
    color:#000;
    font-weight:bold;
    transition:0.3s;
}
.back-btn:hover { background:#e6c200; }

@keyframes fadeIn { from {opacity:0; transform: translateY(-20px);} to {opacity:1; transform:translateY(0);} }
</style>
</head>
<body>

<div class="form-container">
    <h2>Edit Employee</h2>

    <?php if($message): ?>
        <div class="error"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="full_name" placeholder="Full Name" value="<?php echo htmlspecialchars($employee['full_name']); ?>" required>
        <input type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($employee['username']); ?>" required>
        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($employee['email']); ?>" required>
        <input type="text" name="phone" placeholder="Phone Number" value="<?php echo htmlspecialchars($employee['phone']); ?>" required>
        <select name="farm_type" required>
            <option value="">Select Farm Type</option>
            <?php foreach($farm_types as $type): ?>
                <option value="<?php echo $type; ?>" <?php if($employee['farm_type'] == $type) echo 'selected'; ?>><?php echo $type; ?></option>
            <?php endforeach; ?>
        </select>
        <input type="password" name="password" placeholder="New Password (Leave blank to keep current)">
        <button type="submit">Update Employee</button>
    </form>

    <a href="manage_employees.php" class="back-btn">⬅ Back to Manage Employees</a>
</div>

</body>
</html>
