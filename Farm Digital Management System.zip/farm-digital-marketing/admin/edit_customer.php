<?php
session_start();
include('../config.php');

// Only allow admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Check if customer ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: customer_registration.php");
    exit;
}

$customer_id = intval($_GET['id']);
$message = "";

// Fetch existing customer data
$result = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = $customer_id LIMIT 1");
if (!$result || mysqli_num_rows($result) === 0) {
    $_SESSION['message'] = "Customer not found!";
    header("Location: customer_registration.php");
    exit;
}

$customer = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $farm_available = trim($_POST['farm_available']);
    $password = trim($_POST['password']);

    // Update customer details
    $update_query = "UPDATE customers SET 
                        full_name='$full_name',
                        email='$email',
                        phone='$phone',
                        farm_available='$farm_available'";

    if (!empty($password)) {
        $update_query .= ", password='$password'";
    }

    $update_query .= " WHERE customer_id=$customer_id";

    if (mysqli_query($conn, $update_query)) {
        $message = "Customer updated successfully!";
        // Refresh data
        $result = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = $customer_id LIMIT 1");
        $customer = mysqli_fetch_assoc($result);
    } else {
        $message = "Error updating customer: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Customer</title>
<style>
body { margin:0; padding:0; font-family:'Segoe UI',sans-serif; display:flex; justify-content:center; align-items:center; min-height:100vh; 
       background: linear-gradient(-45deg,#76b852,#8DC26F,#FF6F61,#00BFFF); background-size:400% 400%; animation: gradientBG 12s ease infinite; color:#fff; }
@keyframes gradientBG {0%{background-position:0% 50%;}50%{background-position:100% 50%;}100%{background-position:0% 50%;}}

.form-container { background: rgba(255,255,255,0.1); backdrop-filter: blur(12px); padding:30px 40px; border-radius:15px; width:400px; box-shadow:0 8px 25px rgba(0,0,0,0.3); animation:fadeIn 1s ease; }
@keyframes fadeIn { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }
.form-container h2 { text-align:center; margin-bottom:20px; text-shadow:1px 1px 3px rgba(0,0,0,0.4); }
.form-container input, .form-container select { width:100%; padding:12px; margin:10px 0; border:none; border-radius:8px; outline:none; font-size:1rem; }
.submit-btn { width:100%; padding:12px; margin-top:10px; background:#FF6F61; border:none; color:#fff; font-size:1.1rem; font-weight:bold; border-radius:8px; cursor:pointer; transition:0.3s; }
.submit-btn:hover { background:#e65c50; transform:translateY(-2px); box-shadow:0 5px 15px rgba(0,0,0,0.3); }
.message { text-align:center; margin-bottom:10px; font-weight:bold; color:#0f0; }
.back-link { text-align:center; margin-top:15px; }
.back-link a { color:#fff; text-decoration:none; font-weight:bold; transition:0.3s; }
.back-link a:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="form-container">
    <h2>Edit Customer</h2>

    <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="full_name" placeholder="Full Name" value="<?php echo htmlspecialchars($customer['full_name']); ?>" required>
        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($customer['email']); ?>" required>
        <input type="text" name="phone" placeholder="Phone" value="<?php echo htmlspecialchars($customer['phone']); ?>">
        <select name="farm_available" required>
            <option value="">-- Select Farm Seed --</option>
            <option value="Wheat" <?php if($customer['farm_available']=='Wheat') echo 'selected'; ?>>Wheat</option>
            <option value="Rice" <?php if($customer['farm_available']=='Rice') echo 'selected'; ?>>Rice</option>
            <option value="Corn" <?php if($customer['farm_available']=='Corn') echo 'selected'; ?>>Corn</option>
            <option value="Soybean" <?php if($customer['farm_available']=='Soybean') echo 'selected'; ?>>Soybean</option>
            <option value="Vegetables" <?php if($customer['farm_available']=='Vegetables') echo 'selected'; ?>>Vegetables</option>
            <option value="Fruits" <?php if($customer['farm_available']=='Fruits') echo 'selected'; ?>>Fruits</option>
        </select>
        <input type="password" name="password" placeholder="New Password (leave blank to keep current)">
        <button type="submit" class="submit-btn">Update Customer</button>
    </form>

    <div class="back-link">
        <a href="customer_registration.php">⬅ Back to Customer List</a>
    </div>
</div>

</body>
</html>
