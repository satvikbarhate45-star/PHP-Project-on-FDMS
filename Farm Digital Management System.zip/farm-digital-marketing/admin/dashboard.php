<?php
// admin/dashboard.php
session_start();

// Redirect if not logged in as admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== "admin") {
    header("Location: login.php");
    exit;
}

$adminName = "Admin"; // Static since we hardcoded login
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      color: #fff;

      /* Unique farm-style background */
      background: 
        linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
        url("../assets/tractor123.jpg") no-repeat center center fixed;
      background-size: cover;
    }

    header {
      padding: 20px;
      text-align: center;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(6px);
      font-size: 1.6rem;
      font-weight: bold;
      letter-spacing: 1px;
    }

    .container {
      flex: 1;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 25px;
      padding: 40px;
      justify-items: center;
    }

    .card {
      width: 180px;
      height: 160px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      transition: all 0.3s ease;
      text-decoration: none;
      color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      position: relative;
      overflow: hidden;
    }

    .card::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: conic-gradient(#76b852, #8DC26F, #FF6F61, #00BFFF, #76b852);
      animation: rotate 6s linear infinite;
      opacity: 0.15;
    }

    @keyframes rotate {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .card:hover {
      transform: scale(1.08);
      box-shadow: 0 10px 25px rgba(0,0,0,0.4);
    }

    .card h3 {
      margin: 10px 0 5px 0;
      font-size: 1.1rem;
    }

    .card p {
      font-size: 0.85rem;
      opacity: 0.85;
    }

    .icon {
      font-size: 2.5rem;
      margin-bottom: 10px;
    }

    .logout {
      display: inline-block;
      margin: 20px auto;
      padding: 12px 25px;
      background: #FF6F61;
      color: #fff;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
      transition: 0.3s;
    }

    .logout:hover {
      background: #e65c50;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>

  <header>
    🌾 Welcome, <?php echo $adminName; ?> | Admin Dashboard
  </header>

  <div class="container">
    <a href="employees.php" class="card">
      <div class="icon">👨‍🌾</div>
      <h3>Employees</h3>
      <p>Manage Traders</p>
    </a>
    <a href="customer_registration.php" class="card">
      <div class="icon">👥</div>
      <h3>Customers</h3>
      <p>View Data</p>
    </a>
    <a href="schedule.php" class="card">
      <div class="icon">📅</div>
      <h3>Schedule</h3>
      <p>Market Days</p>
    </a>
    <a href="auctions.php" class="card">
      <div class="icon">📈</div>
      <h3>Auctions</h3>
      <p>Track Bids</p>
    </a>
  </div>

  <div style="text-align:center;">
    <a href="logout.php" class="logout">Logout</a>
  </div>

</body>
</html>
