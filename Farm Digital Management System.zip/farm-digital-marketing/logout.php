<?php
session_start();

// Clear all session variables
session_unset();

// Destroy the session
session_destroy();

// Redirect to main login page (can be admin/login.php, employee/login.php, or customer/login.php)
header("Location: index.php"); // Change 'index.php' to your main landing/login page
exit;
?>
