-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2025 at 06:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farm_market`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `farm_available` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `full_name`, `email`, `password`, `phone`, `farm_available`, `created_at`) VALUES
(3, 'Rushikesh', 'Rushi@gmail.com', '1234', '7499256365', 'Soybean', '2025-10-03 18:30:00'),
(4, 'Darshan Jadhav', 'darshan@gmail.com', '1234', '9523670976', 'Soybean', '2025-10-03 18:30:00'),
(5, 'Rushikesh Vinod Jadhav', 'Rushi12@gmail.com', '1234', '8544332212', 'Corn', '2025-10-04 18:30:00'),
(6, 'Aniket Sarjerao Barhate', 'satvikbarhate45@gmail.com', '1234', '7589256358', 'Fruits', '2025-10-04 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `customer_farming`
--

CREATE TABLE `customer_farming` (
  `farming_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `seed_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `available_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_login`
--

CREATE TABLE `customer_login` (
  `login_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `farm_seed_type` varchar(255) NOT NULL,
  `login_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_login`
--

INSERT INTO `customer_login` (`login_id`, `customer_id`, `farm_seed_type`, `login_date`) VALUES
(5, 3, 'Soybean', '2025-10-05 06:29:47'),
(6, 4, 'Wheat', '2025-10-05 06:30:20'),
(7, 4, 'Soybean', '2025-10-05 06:30:39'),
(8, 4, 'Soybean', '2025-10-05 06:31:38'),
(9, 6, 'Fruits', '2025-10-05 06:35:13'),
(10, 6, 'Fruits', '2025-10-05 06:37:08');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `farm_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `full_name`, `username`, `password`, `email`, `phone`, `farm_type`, `created_at`) VALUES
(2, 'Gaurav Khute', 'Admin', '$2y$10$UwuVxdhsJQjUWh2fP951neODmbtoi38p15lvlrARG0KfU3IPYmMEG', 'satvikbarhate45@gmail.com', '7589256358', 'Vegetables', '2025-10-03 16:50:28'),
(3, 'Gaurav Machindra Khute', 'Admin1', '$2y$10$Mgf8CUUW/XlBT3md4cH4Vu0MTJDAgIbH9UR0/dIbjRb9jV4.sld56', 'admin@mail.com', '54555555555', 'Fruits', '2025-10-03 17:42:10'),
(4, 'Sudarshan', 'S_1234', '$2y$10$grorSmsLcLUk1v3xRgODNu4otdIdN0och8zof5rJf2KuVTsa45ngO', 'sudarshan@gmail.com', '76322817734', 'Organic', '2025-10-04 13:37:43');

-- --------------------------------------------------------

--
-- Table structure for table `employee_activity`
--

CREATE TABLE `employee_activity` (
  `activity_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(100) NOT NULL,
  `farm_seed_type` varchar(100) NOT NULL,
  `profit` decimal(10,2) DEFAULT 0.00,
  `loss` decimal(10,2) DEFAULT 0.00,
  `activity_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_activity`
--

INSERT INTO `employee_activity` (`activity_id`, `employee_id`, `employee_name`, `farm_seed_type`, `profit`, `loss`, `activity_date`) VALUES
(2, 2, 'Gaurav Machindra Khute', 'Sugarcane', 90000.00, 12000.00, '2025-10-04'),
(3, 4, 'Sudarshan Jadhav', 'Organic', 34000.00, 2300.00, '2025-10-04');

-- --------------------------------------------------------

--
-- Table structure for table `employee_requests`
--

CREATE TABLE `employee_requests` (
  `request_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Accepted','Rejected') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_visits`
--

CREATE TABLE `employee_visits` (
  `visit_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `availability` enum('Morning','Evening','Full Day') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farm_schedule`
--

CREATE TABLE `farm_schedule` (
  `schedule_id` int(11) NOT NULL,
  `activity_name` varchar(100) NOT NULL,
  `farm_seed_type` varchar(100) NOT NULL,
  `schedule_date` date NOT NULL,
  `assigned_employee` varchar(100) NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farm_schedule`
--

INSERT INTO `farm_schedule` (`schedule_id`, `activity_name`, `farm_seed_type`, `schedule_date`, `assigned_employee`, `remarks`, `created_at`) VALUES
(2, 'Market available of Soyabine', 'Wheat', '2025-10-04', 'Aniket Barhate', 'Soyabin is Imported from maharashtra And export at Gujarat', '2025-10-04 12:04:04'),
(3, 'Rice Available for Selling and Solding', 'Rice', '2025-10-04', 'Sudharshan', 'Rice Import from Rajesthan and Emport at Maharashtra', '2025-10-04 13:44:25');

-- --------------------------------------------------------

--
-- Table structure for table `seed_auctions`
--

CREATE TABLE `seed_auctions` (
  `auction_id` int(11) NOT NULL,
  `seed_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `auction_date` date NOT NULL,
  `employee_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seed_auctions`
--

INSERT INTO `seed_auctions` (`auction_id`, `seed_name`, `price`, `auction_date`, `employee_id`) VALUES
(1, 'Onion', 3100.00, '2025-10-04', 2),
(2, 'Vegetables', 2000.00, '2025-10-04', 3),
(3, 'Wheat', 5400.00, '2025-10-04', 4),
(4, 'Cotton', 9000.00, '2025-10-04', 4),
(5, 'Soyabine', 4500.00, '2025-10-04', 3),
(6, 'Fruits', 12000.00, '2025-10-04', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `customer_farming`
--
ALTER TABLE `customer_farming`
  ADD PRIMARY KEY (`farming_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `customer_login`
--
ALTER TABLE `customer_login`
  ADD PRIMARY KEY (`login_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `employee_activity`
--
ALTER TABLE `employee_activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `employee_requests`
--
ALTER TABLE `employee_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `employee_visits`
--
ALTER TABLE `employee_visits`
  ADD PRIMARY KEY (`visit_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `farm_schedule`
--
ALTER TABLE `farm_schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `seed_auctions`
--
ALTER TABLE `seed_auctions`
  ADD PRIMARY KEY (`auction_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_farming`
--
ALTER TABLE `customer_farming`
  MODIFY `farming_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_login`
--
ALTER TABLE `customer_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `employee_activity`
--
ALTER TABLE `employee_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee_requests`
--
ALTER TABLE `employee_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee_visits`
--
ALTER TABLE `employee_visits`
  MODIFY `visit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farm_schedule`
--
ALTER TABLE `farm_schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seed_auctions`
--
ALTER TABLE `seed_auctions`
  MODIFY `auction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_farming`
--
ALTER TABLE `customer_farming`
  ADD CONSTRAINT `customer_farming_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_login`
--
ALTER TABLE `customer_login`
  ADD CONSTRAINT `customer_login_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `employee_activity`
--
ALTER TABLE `employee_activity`
  ADD CONSTRAINT `employee_activity_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_requests`
--
ALTER TABLE `employee_requests`
  ADD CONSTRAINT `employee_requests_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  ADD CONSTRAINT `employee_requests_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `employee_visits`
--
ALTER TABLE `employee_visits`
  ADD CONSTRAINT `employee_visits_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE;

--
-- Constraints for table `seed_auctions`
--
ALTER TABLE `seed_auctions`
  ADD CONSTRAINT `seed_auctions_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
